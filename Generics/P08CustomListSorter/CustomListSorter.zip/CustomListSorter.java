package P08CustomListSorter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class CustomListSorter<T extends  Comparable<T>> {
    private List<T> elements;

    public CustomListSorter() {
        this.elements = new ArrayList<>();
    }

    public void add (T element){
        this.elements.add(element);
    }

    public T remove(int index){
        if (index >= 0 && index <= elements.size() -1){
            return this.elements.remove(index);
        }
        throw  new IndexOutOfBoundsException("Invalid index");
    }

    public boolean contains (T element){
        return  this.elements.contains(element);
    }

    public void swap (int firstIndex, int secondIndex){
        T firstElementIndex = this.elements.get(firstIndex);
        T secondElementIndex = this.elements.get(secondIndex);
        this.elements.set(firstIndex,secondElementIndex);
        this.elements.set(secondIndex,firstElementIndex);
    }
    public int countGreaterThan  (T element){
        int count = 0;
        for (T elementInList : this.elements) {
            if (elementInList.compareTo(element) > 0){
                count++;
            }

        }
        return count;
    }
    public T getMax (){
        return this.elements.stream()
                .max(Comparator.naturalOrder())
                .get();
    }
    public T getMin() {
        return  this.elements.stream()
                .min((e1,e2 )-> e1.compareTo(e2))
                .get();
    }

    public void print(){
        for (T element : elements) {
            System.out.println(element);
        }
    }

    public void sort() {
        this.elements.sort((e1,e2) -> e1.compareTo(e2));
    }
}

